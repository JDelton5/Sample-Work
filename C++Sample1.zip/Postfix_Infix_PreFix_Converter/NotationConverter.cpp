#include "NotationConverter.hpp"
#include "Deque.cpp"

class NotationConverter : public NotationConverterInterface {
public:
    std::string postfixToInfix(std::string inStr) override {
        std::string infix;
        for(int i=0; i<(int)inStr.length(); i++){
            if(isalpha(inStr[i])){
                //convert character to string and add to back of deque
                std::string str(1, inStr[i]);
                D.pushFront(str);
            }else if(inStr[i]==' ') {
                //Ignore spaces
                continue;
            }else{
                //if the character is an operand, create the infix string for those two specific operands
                std::string operand1, operand2;
                operand2+=D.front();
                D.popFront();
                operand1+=D.front();
                D.popFront();
                std::string temp="("+operand1+" "+inStr[i]+" "+operand2+")";
                D.pushFront(temp);
            }
        }
        //while deque is not empty, add the nodes to the infix string and remove them from the deque
        while(!D.empty()){
            infix+=D.front();
            D.popFront();
        }

        return infix;
    }

    std::string postfixToPrefix(std::string inStr) override {
        //go from postfix to infix and infix to prefix since those methods are already implemented
        std::string prefix;
        prefix=postfixToInfix(inStr);
        prefix=infixToPrefix(prefix);
        return prefix;
    }

    std::string infixToPostfix(std::string inStr) override {
        std::string postfix;

        for(int i=0; i<(int)inStr.length(); i++){
            //convet character to string
            std::string str(1, inStr[i]);
            //if the character is an operand, add it to the postfix string
            if(isalpha(inStr[i])){
                postfix+=str+" ";
            }else if(inStr[i]==' '){
                //skip white spaces
                continue;
            }else if(inStr[i]=='(') {
                //save the ( into the deque 
                D.pushFront(str);
            //if the character is ), it means we just read a full operation between two operands
            }else if(inStr[i]==')') {
                //while the character in the front of the deque is not (, then it means it's an operator and we add it to the string
                while(!D.empty() && D.front()!="(") {
                    postfix+=D.front()+" ";
                    D.popFront();
                }
                //remove starting ( from deque as that full operation has been read
                D.popFront();
            }else {
                //the character is an operator, add it to the front of the deque
                D.pushFront(str);
            }
        }
        //empty deque
        while(!D.empty()){
            D.popFront();
        }
        //remove last space from string
        postfix.erase(postfix.size()-1);
        return postfix;          
    }

    std::string infixToPrefix(std::string inStr) override {
        std::string prefix;
        //reading the input string backward
        for(int i=inStr.length()-1; i>=0; i--){
            //convet character to string
            std::string str(1, inStr[i]);
            //if the character is an operand, add it to the prefix string followed by the prefix string itself (which contains the character previously scanned)
            if(isalpha(inStr[i])){
                prefix=str+" "+prefix;
            }else if(inStr[i]==' '){
                //skip white spaces
                continue;
            }else if(inStr[i]==')') {
                //save the ) into the deque 
                D.pushFront(str);
            //if the character is (, it means we just read a full operation between two operands
            }else if(inStr[i]=='(') {
                //while the character in the front of the deque is not ), then it means it's an operator and we add it at the beginning of the prefix string
                while(!D.empty() && D.front()!=")") {
                    prefix=D.front()+" "+prefix;
                    D.popFront();
                }
                //remove starting ) from deque as that full operation has been read
                D.popFront();
            }else {
                //the character is an operator, add it to the front of the deque
                D.pushFront(str);
            }
        }
        //empty deque
        while(!D.empty()){
            D.popFront();
        }
        //remove last space from string
        prefix.erase(prefix.size()-1);
        return prefix; 
    }

    std::string prefixToInfix(std::string inStr) override {
        std::string infix;
        //reading the input string backward
        for(int i=inStr.length()-1; i>=0; i--){
            if(isalpha(inStr[i])){
                //convert character to string and add to back of deque
                std::string str(1, inStr[i]);
                D.pushFront(str);
            }else if(inStr[i]==' ') {
                //Ignore spaces
                continue;
            }else{
                //if the character is an operand, create the infix string for those two specific operands
                std::string operand1, operand2;
                operand1+=D.front();
                D.popFront();
                operand2+=D.front();
                D.popFront();
                std::string temp="("+operand1+" "+inStr[i]+" "+operand2+")";
                D.pushFront(temp);
            }
        }
        //while deque is not empty, add the nodes to the infix string and remove them from the deque
        while(!D.empty()){
            infix+=D.front();
            D.popFront();
        }
        
        return infix;
    }

    std::string prefixToPostfix(std::string inStr) override {
        //go from prefix to infix and infix to postfix since those methods are already implemented
        std::string postfix;
        postfix=prefixToInfix(inStr);
        postfix=infixToPostfix(postfix);
        return postfix;
    }

private:
    Deque<std::string> D;
};
