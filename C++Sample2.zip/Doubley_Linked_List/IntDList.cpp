#include "IntDList.hpp"

#include <sstream>
#include <iostream>
//constructor
IntDLList::IntDLList() : ListHead(nullptr) {}
//deconstructor
IntDLList::~IntDLList()
{
    while (ListHead)
    {
        IntDLLNode *temp = ListHead;
        ListHead = ListHead->next;
        delete temp;
    }
}

void IntDLList::insertInOrder(int value)
{
    IntDLLNode *newNode = new IntDLLNode(value);
    //if list is empty, insert node at the beginning
    if (!ListHead)
    {
        ListHead = newNode;
    //if the head is already greater than the value to insert, insert node at the beginning
    }else if(ListHead->info>=newNode->info)
    {
        newNode->next=ListHead;
        ListHead->prev=newNode;
        ListHead=newNode;
    }else{
        IntDLLNode *current = ListHead;
        //iterate through list until a node with greater value is found (stops at the node before this)
        while(current->next!=nullptr&&current->next->info<newNode->info){
            current=current->next;
        }
        //if the node is greater than every other node, insert it at the end
        if(current->next==nullptr){
            addToTail(value);
        }else{//general insertion between two nodes for doubly linked list
            newNode->next=current->next;
            current->next=newNode;
            newNode->next->prev=newNode;
            newNode->prev=current;
        }
    }
}

void IntDLList::addToTail(int value)
{
    IntDLLNode *newNode = new IntDLLNode(value);
    //if list is empty, value is added at beginning
    if (!ListHead)
    {
        ListHead = newNode;
    }
    else
    {//iterate through list until the end is reached, then add new node
        IntDLLNode *current = ListHead;
        while (current->next)
        {
            current = current->next;
        }
        current->next = newNode;
        newNode->prev = current;
        newNode->next=nullptr;
    }
}

int IntDLList::deleteFromHead()
{
    int info=0;
    if (ListHead)
    {//make ListHead point to second element, then free temp (points to first element), and return its value
        IntDLLNode *temp = ListHead;
        ListHead = ListHead->next;
        if (ListHead)
        {
            ListHead->prev = nullptr;
        }
        info=temp->info;
        delete temp;
    }
    return info;
}

int IntDLList::deleteFromTail()
{
    int info=0;
    //if the list is not empty, then proceed to delete tail
    if (ListHead)
    {
        if (!ListHead->next)
        {
            // If there is only one node in the list 
            info=ListHead->info;
            delete ListHead;
            ListHead = nullptr;
        }
        else
        {
            IntDLLNode *current = ListHead;
            //while the node after current->next is null
            while (current->next->next)
            {
                current = current->next;
            }
            //save info of node to be deleted
            info=current->next->info;
            delete current->next;
            current->next = nullptr;
        }
    }
    return info;
}

void IntDLList::deleteNode(int value)
{
    //if the node is in the list, then delete it
    if(isInList(value)){
        IntDLLNode *current = ListHead;
        //iterate through list to find value
        while(current->info!=value){
            current=current->next;
        }
        //if the value is not the last node, then change next link of node to be deleted
        if(current->next!=nullptr){
            current->next->prev = current->prev;
        }
        //if the value is not the first node, then change prev link of node to be deleted
        if(current->prev!=nullptr){
            current->prev->next = current->next;
        }
        delete current;
    }
    
}

bool IntDLList::isInList(int value) const
{
    //if the list is not empty, then search for value
    if(ListHead){
        IntDLLNode *current = ListHead;
        while(current->info!=value){
            current=current->next;
        }
        //if the value is found, return true
        if(current->info==value) return true;
    }
    return false;
}

string IntDLList::addToString() const
{
    IntDLLNode *current = ListHead;
    // Using std::stringstream to concatenate and manipulate strings
    std::stringstream ss;
    //while loop to add all the info values to ss variable
    while(current){
        ss << current->info;
        current=current->next;
    }
    
    // Convert the stringstream to a string
    std::string result = ss.str();
    return result;
}
